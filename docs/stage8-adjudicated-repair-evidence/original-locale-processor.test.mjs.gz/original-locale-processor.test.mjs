import fs from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
const root=process.env.STAGE8_REVIEW_ROOT;
const {stage8Fixture}=await import(root+'/test/stage8Fixture.js');
const {createStage7Runtime}=await import(root+'/src/stage7Runtime.js');
const {createSettings,settingsKey}=await import(root+'/src/bot/settings.js');
const {createRouter}=await import(root+'/src/bot/router.js');
const {createUpdateProcessor}=await import(root+'/src/bot/updateProcessor.js');
const {interpretUrgentSymptoms,urgentReply}=await import(root+'/src/bot/triage.js');
const {JOURNAL_COPY}=await import(root+'/src/stage7Registry.js');
const original=JSON.parse(fs.readFileSync(root+'/test/stage8-scoped-repair/original-cases.json')).cases;
const references=JSON.parse(fs.readFileSync(root+'/test/stage8-scoped-repair/reference-cases.json')).cases;
const shard=process.env.STAGE8_GATE_TEST_SHARD===undefined?null:Number(process.env.STAGE8_GATE_TEST_SHARD);
if(shard!==null&&![0,1,2].includes(shard))throw Error('INVALID_TEST_SHARD');
const output='/private/tmp/stage8-gate-adjudication/locale-processor-'+(shard??'all')+'-results.json';
const results=[];
function record(r){results.push(r);fs.writeFileSync(output,JSON.stringify({count:results.length,pass:results.filter(r=>r.pass).length,fail:results.filter(r=>!r.pass).length,results},null,2));}
async function tap(app,f,card,label){const actor=await app.companion.interactions.authenticate(f.input);await app.companion.interactions.bind(actor,card.stage7InteractionId,42);const b=card.replyMarkup.inline_keyboard.flat().find(b=>b.text===label||b.text.endsWith(' '+label));assert.ok(b);return app.companion.handle({...f.input,callback:{id:'independent',data:b.callback_data,from:{id:123},message:{message_id:42,chat:{id:123,type:'private'}}}});}
async function setup(t,locale,lane){
 t.mock.method(globalThis,'fetch',()=>{throw Error('REAL_NETWORK_FORBIDDEN');});
 const f=await stage8Fixture(t);await f.db.setLocale('a',locale);
 await f.app.identity.recordTelegram({...f.input,message:{chat:{id:123,type:'private'},from:{id:123,is_bot:false,first_name:'Synthetic'}}});
 const app=await createStage7Runtime({...f,environment:{STAGE7_COMPANION:'on',STAGE7_COMPANION_USER_IDS:'a',PHASE4_BETA_PILOT_USER_ID:'a'},now:f.now});
 const settings=createSettings({db:f.db,stage8:f.app,now:f.now}),router=createRouter({db:f.db,stage8:f.app,now:f.now,coachFor(){return null;}});
 if(lane==='name')await settings({...f.input,text:'/name'});
 if(lane==='note'){const j=JOURNAL_COPY[locale];let card=await app.companion.handle({...f.input,text:'/journal'});card=await tap(app,f,card,j.topics[0]);card=await tap(app,f,card,j.yes);card=await tap(app,f,card,j.details[0]);await tap(app,f,card,j.note);}
 if(lane==='coach')await app.coach.handle({...f.input,text:'/coach'});
 const observed={sends:0,consumers:0,captures:0};
 const processor=createUpdateProcessor({db:f.db,now:f.now,resolveUser:id=>f.db.resolveUserByChatId(id),authenticatedIdentity:input=>{observed.captures++;return f.app.captureIdentity(input);},stage7Inbound:input=>{observed.consumers++;return app.stage7Inbound(input);},stage7Reply:app.stage7Reply,handleMessage:async input=>{observed.consumers++;return (await settings(input))??router.handle(input);},sendReply:input=>f.app.sendReply(value=>app.sendReply(async delivered=>{observed.reply=delivered.reply;observed.sends++;return{sent:true,messageId:84};},value),input)});
 const snapshot=async()=>({name:await f.db.getState(settingsKey('a')),interactions:(await f.db.raw.execute("SELECT * FROM quick_action_interactions WHERE user_id='a'")).rows,identity:(await f.db.raw.execute('SELECT * FROM recipient_identity_sources')).rows});
 return{f,app,processor,observed,snapshot};
}
function update(id,text){return{update_id:id,message:{text,message_id:id,chat:{id:123,type:'private'},from:{id:123,is_bot:false,first_name:'Synthetic'}}};}

const corpus=JSON.parse(fs.readFileSync(root+'/test/stage8-safety-gate/cases.json'));
const unparsed=[['en','My chest pain started yesterday and persists.'],['zh-TW','我昨天胸痛而且持續。'],['vi','Tôi đau ngực hôm qua và vẫn còn.'],['mixed','My chest pain started yesterday and 持續。']].map(([locale,text])=>({id:'unparsed-current-'+locale,locale,text,expected:'POSSIBLE_CURRENT_URGENT',family:'unparsed-current'}));
const jobs=[{"id": "quoted-post-assertion-zh", "locale": "zh-TW", "text": "「胸痛」是我現在感到的症狀。", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "name"}, {"id": "quoted-post-assertion-zh", "locale": "zh-TW", "text": "「胸痛」是我現在感到的症狀。", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "note"}, {"id": "quoted-post-assertion-zh", "locale": "zh-TW", "text": "「胸痛」是我現在感到的症狀。", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "coach"}, {"id": "quoted-post-assertion-zh", "locale": "zh-TW", "text": "「胸痛」是我現在感到的症狀。", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "health"}, {"id": "quoted-post-assertion-vi", "locale": "vi", "text": "\"đau ngực\" là triệu chứng tôi đang cảm thấy.", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "name"}, {"id": "quoted-post-assertion-vi", "locale": "vi", "text": "\"đau ngực\" là triệu chứng tôi đang cảm thấy.", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "note"}, {"id": "quoted-post-assertion-vi", "locale": "vi", "text": "\"đau ngực\" là triệu chứng tôi đang cảm thấy.", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "coach"}, {"id": "quoted-post-assertion-vi", "locale": "vi", "text": "\"đau ngực\" là triệu chứng tôi đang cảm thấy.", "expected": "POSSIBLE_CURRENT_URGENT", "lane": "health"}];
fs.writeFileSync('/private/tmp/stage8-gate-adjudication/locale-processor-'+(shard??'all')+'-cases.json',JSON.stringify({frozenBeforeExecution:true,jobs},null,2));
for(const [i,c]of jobs.entries())if(shard===null||i%3===shard)test('gate actual ingress '+c.id+' '+c.lane,async t=>{
 const locale=c.locale==='mixed'?'en':c.locale;const {f,processor,observed,snapshot}=await setup(t,locale,c.lane);const before=await snapshot();const peer=await f.db.getUser('b');
 const text=c.text+(c.lane==='health'?' What is my HRV today?':'');const u=update(988001+i,text);
 const outcome=await processor.processUpdate(u),replay=await processor.processUpdate(u),after=await snapshot();
 const scopeReads=Number((await f.db.raw.execute('SELECT count(*) n FROM stage8_scoped_read_audit')).rows[0].n),reply=typeof observed.reply==='string'?observed.reply:observed.reply?.text;
 const failures=[];
 if(outcome.outcome!=='processed'||replay.outcome!=='replayed'||observed.sends!==1)failures.push('transport-or-replay');
 if(c.expected!=='CLEARLY_NONURGENT'){
  if(reply!==urgentReply(locale))failures.push('MISSING_SAFETY');if(JSON.stringify(before)!==JSON.stringify(after))failures.push('PERSISTENCE_CHANGED');if(scopeReads)failures.push('ORDINARY_SCOPE_READ');if(observed.consumers||observed.captures)failures.push('ORDINARY_CONSUMER');
 }else{
  if(reply===urgentReply(locale))failures.push('FALSE_EMERGENCY');if(!observed.consumers)failures.push('NORMAL_CONSUMER_BLOCKED');
  if(c.lane==='name'&&JSON.parse(after.name??'{}').pendingName!==text)failures.push('NAME_FLOW_BLOCKED');if(c.lane==='note'&&!after.interactions.some(r=>r.note===text&&r.state==='CONFIRM'))failures.push('NOTE_FLOW_BLOCKED');
 }
 if(JSON.stringify(peer)!==JSON.stringify(await f.db.getUser('b')))failures.push('PEER_CHANGED');
 const classification=interpretUrgentSymptoms(text).decision;if(c.id.startsWith('quoted-post-assertion') ? classification==='CLEARLY_NONURGENT' : classification!==c.expected)failures.push('CLASSIFICATION_CHANGED');
 record({id:c.id,locale,lane:c.lane,text,expected:c.expected,classification,pass:!failures.length,failures,scopeReads,reply,observed:{sends:observed.sends,consumers:observed.consumers,captures:observed.captures},statePreserved:JSON.stringify(before)===JSON.stringify(after),peerPreserved:JSON.stringify(peer)===JSON.stringify(await f.db.getUser('b'))});assert.deepEqual(failures,[],JSON.stringify(results.at(-1)));
});
